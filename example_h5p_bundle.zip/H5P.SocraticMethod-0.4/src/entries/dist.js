import '@styles/h5p-socratic-method.scss';
import SocraticMethod from '@scripts/h5p-socratic-method.js';

// Load library
H5P.SocraticMethod = SocraticMethod;
